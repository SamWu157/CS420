enter moves letter followed by number, example: a4
