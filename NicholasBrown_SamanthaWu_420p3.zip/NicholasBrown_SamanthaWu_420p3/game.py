#!/usr/bin/env python

import random, time

depth_limit = 5
time_limit = 5


class Board(object):
    winning_combos = ([0, 1, 2, 3], [1, 2, 3, 4], [2, 3, 4, 5], [3, 4, 5, 6], [4, 5, 6, 7], [8, 9, 10, 11], [9, 10, 11, 12],
                      [10, 11, 12, 13], [11, 12, 13, 14], [12, 13, 14, 15], [16, 17, 18, 19], [17, 18, 19, 20], [18, 19, 20, 21],
                      [19, 20, 21, 22], [20, 21, 22, 23], [24, 25, 26, 27], [25, 26, 27, 28], [26, 27, 28, 29], [27, 28, 29, 30],
                      [28, 29, 30, 31], [32, 33, 34, 35], [33, 34, 35, 36], [34, 35, 36, 37], [35, 36, 37, 38], [36, 37, 38, 39],
                      [40, 41, 42, 43], [41, 42, 43, 44], [42, 43, 44, 45], [43, 44, 45, 46], [44, 45, 46, 47], [48, 49, 50, 51],
                      [49, 50, 51, 52], [50, 51, 52, 53], [51, 52, 53, 54], [52, 53, 54, 55], [56, 57, 58, 59], [57, 58, 59, 60],
                      [58, 59, 60, 61], [59, 60, 61, 62], [60, 61, 62, 63], [0, 8, 16, 24], [1, 9, 17, 25], [2, 10, 18, 26], [3, 11, 19, 27],
                      [4, 12, 20, 28], [5, 13, 21, 29], [6, 14, 22, 30], [7, 15, 23, 31], [8, 16, 24, 32], [9, 17, 25, 33], [10, 18, 26, 34],
                      [11, 19, 27, 35], [12, 20, 28, 36], [13, 21, 29, 37], [14, 22, 30, 38], [15, 23, 31, 39], [16, 24, 32, 40],
                      [17, 25, 33, 41], [18, 26, 34, 42], [19, 27, 35, 43], [20, 28, 36, 44], [21, 29, 37, 45], [22, 30, 38, 46],
                      [23, 31, 39, 47], [24, 32, 40, 48], [25, 33, 41, 49], [26, 34, 42, 50], [27, 35, 43, 51], [28, 36, 44, 52],
                      [29, 37, 45, 53], [30, 38, 46, 54], [31, 39, 47, 55], [32, 40, 48, 56], [33, 41, 49, 57], [34, 42, 50, 58],
                      [35, 43, 51, 59], [36, 44, 52, 60], [37, 45, 53, 61], [38, 46, 54, 62], [39, 47, 55, 63], [40, 48, 56, 64])

    winners = ('X-win', 'Draw', 'O-win')

    def __init__(self, grid=[]):

        if len(grid) == 0:
            self.grid = [None for i in range(64)]
        else:
            self.grid = grid

    def show(self):
        line = '\n   1  2  3  4  5  6  7  8'
        for i in range(0, 64):
            if i % 8 == 0:
                print line
                line = ''
            if i == 0:
                line += 'A '
            elif i == 8:
                line += 'B '
            elif i == 16:
                line += 'C '
            elif i == 24:
                line += 'D '
            elif i == 32:
                line += 'E '
            elif i == 40:
                line += 'F '
            elif i == 48:
                line += 'G '
            elif i == 56:
                line += 'H '

            if self.grid[i] is None:
                line += ' - '
            elif self.grid[i] is 'O':
                line += ' O '
            elif self.grid[i] is 'X':
                line += ' X '
            if i == 63:
                print line

    def available_moves(self):
        return [k for k, v in enumerate(self.grid) if v is None]

    def complete(self):
        if None not in [v for v in self.grid]:
            return True
        if self.winner() != None:
            return True
        return False

    def X_won(self):
        return self.winner() == 'X'

    def O_won(self):
        return self.winner() == 'O'

    def tied(self):
        return self.complete() == True and self.winner() is None

    def winner(self):
        for player in ('X', 'O'):
            positions = self.get_player_positions(player)
            for combo in self.winning_combos:
                win = True
                for pos in combo:
                    if pos not in positions:
                        win = False
                if win:
                    return player
        return None

    def get_player_positions(self, player):
        return [k for k, v in enumerate(self.grid) if v == player]

    def make_move(self, position, player):
        self.grid[position] = player

    def evaluation(self, player):
        val = 0
        off_horz = [0, 7, 8, 15, 16, 23, 24, 31, 32, 39, 40, 47, 48, 55, 56, 63, 64]
        off_vert = [0, 1, 2, 3, 4, 5, 6, 7, 56, 57, 58, 59, 60, 61, 62, 63]
        for i in range(0, 64):
            if i not in off_horz:
                if self.grid[i+1] == get_enemy('O') and self.grid[i] == get_enemy('O'):
                    val += 50
                if self.grid[i-1] == get_enemy('O') and self.grid[i] == get_enemy('O'):
                    val += 50
                if self.grid[i-1] == get_enemy('O') and self.grid[i] == get_enemy('O') and self.grid[i+1] == get_enemy('O'):
                    val += 50
                    try:
                        if self.grid[i-2] == get_enemy('O') or self.grid[i+2] == get_enemy('O'):
                            val += 500
                    except IndexError:
                        None
            if i not in off_vert:
                if self.grid[i+8] == get_enemy('O') and self.grid[i] == get_enemy('O'):
                    val += 50
                if self.grid[i-8] == get_enemy('O') and self.grid[i] == get_enemy('O'):
                    val += 50
                if self.grid[i-8] == get_enemy('O') and self.grid[i] == get_enemy('O') and self.grid[i+8] == get_enemy('O'):
                    val += 50
                    try:
                        if self.grid[i-16] == get_enemy('O') or self.grid[i+16] == get_enemy('O'):
                            val += 500
                    except IndexError:
                        None
            if i not in off_horz:
                if self.grid[i+1] == 'O' and self.grid[i] == 'O':
                    val -= 50
                if self.grid[i-1] == 'O' and self.grid[i] == 'O':
                    val -= 50
                if self.grid[i-1] == 'O' and self.grid[i] == 'O' and self.grid[i+1] == 'O':
                    val -= 50
                    try:
                        if self.grid[i-2] == 'O' or self.grid[i+2] == 'O':
                            val -= 500
                    except IndexError:
                        None
            if i not in off_vert:
                if self.grid[i+8] == 'O' and self.grid[i] == 'O':
                    val -= 50
                if self.grid[i-8] == 'O' and self.grid[i] == 'O':
                    val -= 50
                if self.grid[i-8] == 'O' and self.grid[i] == 'O' and self.grid[i+8] == 'O':
                    val -= 50
                    try:
                        if self.grid[i-16] == 'O' or self.grid[i+16] == 'O':
                            val -= 500
                    except IndexError:
                        None
        return val

    def alphabeta(self, node, player, alpha, beta, current_depth):
        if time.time() - start_time > time_limit:
            return self.evaluation(player)
        if node.complete():
            if node.X_won():
                return -10000000
            elif node.tied():
                return 0
            elif node.O_won():
                return 10000000
        if current_depth <= depth_limit or time.time() - start_time < time_limit:
            current_depth += 1
            for move in node.available_moves():
                node.make_move(move, player)
                value = self.alphabeta(node, get_enemy(player), alpha, beta, current_depth)
                node.make_move(move, None)
                if player == 'X':
                    if value > alpha:
                        alpha = value
                    if alpha >= beta:
                        return beta
                else:
                    if value < beta:
                        beta = value
                    if beta <= alpha:
                        return alpha
        else:
            return self.evaluation(player)
        if player == 'X':
            return alpha
        else:
            return beta


def computer_turn(board, player):
    a = -10000000
    choices = []
    if len(board.available_moves()) == 64:
        return 28
    if len(board.available_moves()) == 63:
        if board.grid[28] is None:
            return 28
        else:
            return 27
    for move in board.available_moves():
        board.make_move(move, player)
        value = board.alphabeta(board, get_enemy(player), -10000000, 10000000, 0)
        board.make_move(move, None)
        if value > a:
            a = value
            choices = [move]
        elif value == a:
            choices.append(move)
    return random.choice(choices)


def get_enemy(player):
    if player == 'O':
        return 'X'
    return 'O'

def convert_move(input):
    letter = str(input[0].upper())
    number = int(input[1])
    mult = 0
    coordinate = 0
    if letter == 'A':
        mult = 0
    elif letter == 'B':
        mult = 1
    elif letter == 'C':
        mult = 2
    elif letter == 'D':
        mult = 3
    elif letter == 'E':
        mult = 4
    elif letter == 'F':
        mult = 5
    elif letter == 'G':
        mult = 6
    elif letter == 'H':
        mult = 7
    coordinate = number + 8*mult
    return coordinate - 1

def readable_convert_move(input):
    letter = input / 8
    number = (input % 8) + 1
    if letter == 0:
        letter = 'A'
    elif letter == 1:
        letter = 'B'
    elif letter == 2:
        letter = 'C'
    elif letter == 3:
        letter = 'D'
    elif letter == 4:
        letter = 'E'
    elif letter == 5:
        letter = 'F'
    elif letter == 6:
        letter = 'G'
    elif letter == 7:
        letter = 'H'
    return letter + str(number)


def update_time_limit():
    time_limit = raw_input("How long should the computer think about its moves (in seconds)?: ")

def get_first_player():
    first_player = raw_input("Would you like to go first? (y/n): ")
    if first_player == "y" or first_player == "Y":
        return True
    else:
        return False

def valid_move(input):
    if len(input) != 2:
        return False
    mult = 8
    letter = str(input[0]).upper()
    if letter == 'A':
        mult = 0
    elif letter == 'B':
        mult = 1
    elif letter == 'C':
        mult = 2
    elif letter == 'D':
        mult = 3
    elif letter == 'E':
        mult = 4
    elif letter == 'F':
        mult = 5
    elif letter == 'G':
        mult = 6
    elif letter == 'H':
        mult = 7
    if int(input[1]) > 8 or int(input[1]) < 1:
        return False
    if mult < 0 or mult > 7:
        return False
    return True

if __name__ == "__main__":
    board = Board()
    board.show()
    is_player_first = get_first_player()
    global time_limit
    update_time_limit()
    player_moves = []
    computer_moves = []
    while not board.complete():
        if is_player_first:
            player = 'O'
            player_move = raw_input("Choose your next move: ")
            valid = valid_move(player_move)
            if len(player_move) == 2:
                converted_move = convert_move(player_move)
            while not valid or not converted_move in board.available_moves():
                print "Illegal move."
                player_move = raw_input("Choose your next move: ")
                valid = valid_move(player_move)
                if len(player_move) != 2:
                    valid = False
                else:
                    converted_move = convert_move(player_move)
            player_moves.append(player_move)


            board.make_move(converted_move, player)
            board.show()

            if board.complete():
                break
            player = 'X'
            start_time = time.time()

            computer_move = computer_turn(board, player)
            board.make_move(computer_move, player)
            converted_move = readable_convert_move(computer_move)
            computer_moves.append(converted_move)
            board.show()
            print "My move is:", converted_move
        else:
            player = 'X'
            start_time = time.time()

            computer_move = computer_turn(board, player)
            board.make_move(computer_move, player)
            converted_move = readable_convert_move(computer_move)
            computer_moves.append(converted_move)
            board.show()
            print "My move is:", converted_move

            if board.complete():
                break
            player = 'O'
            player_move = raw_input("Choose your next move: ")
            valid = valid_move(player_move)
            if len(player_move) == 2:
                converted_move = convert_move(player_move)
            while not valid or not converted_move in board.available_moves():
                print "Illegal move."
                player_move = raw_input("Choose your next move: ")
                valid = valid_move(player_move)
                if len(player_move) != 2:
                    valid = False
                else:
                    converted_move = convert_move(player_move)
            player_moves.append(player_move)
            board.make_move(converted_move, player)
            board.show()


    print "winner is", board.winner()
    print "player v opponent"
    if len(player_moves) < len(computer_moves):
        for i in range(len(player_moves)):
            print str(i+1) + ". " + player_moves[i] + " " + computer_moves[i]
    else:
        for i in range(len(computer_moves)):
            print str(i+1) + ". " + player_moves[i] + " " + computer_moves[i]